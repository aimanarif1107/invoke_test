
<div class="container">
    <h1>Results</h1>
        {{ csrf_field() }}
        <?php foreach($survey as $value)
        { 
            if($value['id'] == 1)
            {
            ?>
            <div style="font-size:18px">
                <P><?= $value['question'] ?><BR>
                <a> &nbsp &nbsp a. <18 (Total: <?= $value['a']?>)</a><BR>
                <a> &nbsp &nbsp b. 18 to 35 (Total: <?= $value['b']?>)</a><BR>
                <a> &nbsp &nbsp c. 35 to 60 (Total: <?= $value['c']?>)</a><BR>
                <a> &nbsp &nbsp d. Above 60 (Total: <?= $value['d']?>)</a><BR>
                </p>
            </div>
        <?php } 
            if($value['id'] == 2)
            {
            ?>
            <div style="font-size:18px">
                <P><?= $value['question'] ?><BR>
                <a> &nbsp &nbsp a. Secondary school and below (Total: <?= $value['a']?>)</a><BR>
                <a> &nbsp &nbsp b. Diploma (Total: <?= $value['b']?>)</a><BR>
                <a> &nbsp &nbsp c. Degree (Total: <?= $value['c']?>)</a><BR>
                <a> &nbsp &nbsp d. Post graduate degree (Total: <?= $value['d']?>)</a><BR>
                </p>
            </div>
        <?php } 
            if($value['id'] == 3)
            {
            ?>
            <div style="font-size:18px">
                <P><?= $value['question'] ?><BR>
                <a> &nbsp &nbsp a. Less than RM 1000 (Total: <?= $value['a']?>)</a><BR>
                <a> &nbsp &nbsp b. Between RM1000 to RM3000 (Total: <?= $value['b']?>)</a><BR>
                <a> &nbsp &nbsp c. Between RM3000 to RM5000 (Total: <?= $value['c']?>)</a><BR>
                <a> &nbsp &nbsp d. More than RM5000 (Total: <?= $value['d']?>)</a><BR>
                </p>
             </div>
       <?php }
            if($value['id'] == 4)
            {
            ?>
            <div style="font-size:18px">
                <P><?= $value['question'] ?><BR>
                <a> &nbsp &nbsp a. Male (Total: <?= $value['a']?>)</a><BR>
                <a> &nbsp &nbsp b. Female (Total: <?= $value['b']?>)</a><BR>
                </p>
             </div>
        <?php } ?>
    <?php } ?>
    <!-- <div class="offset-sm-3 col-sm-9">
        <button href="{{ route('question') }}" type="submit"  class="btn btn-primary">Submit Another Survey</button>
    </div> -->
</div>
<style>
.container {
  margin-left: 20%;
  margin-top: 100px;
}
</style> 