    <div class="card" style="width: 270px;margin: 5px">
        <div class="card-block">
            <h3 class="card-title">{{ $survey->a }}</h3>
            <p class="card-text">{{ $survey->b }} is published by {{ $survey->c }}</p>
            <a href="/games" class="btn btn-primary">List Games</a>
        </div>
    </div>