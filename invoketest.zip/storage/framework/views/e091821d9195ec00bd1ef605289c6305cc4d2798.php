
<h2>Please answer this survey</h2>

<form method="post" action="/survey" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <P>1. What is your age group?<BR>
    <input type="radio" name="age" value="a"><18<BR>
    <input type="radio" name="age" value="b">18 to 35<BR>
    <input type="radio" name="age" value="c">35 to 60<BR>
    <input type="radio" name="age" value="d">Above 60<BR>
    </p>

    <P>2. What is your education level?<BR>
    <input type="radio" name="education" value="a">Secondary school and below<BR>
    <input type="radio" name="education" value="b">Diploma<BR>
    <input type="radio" name="education" value="c">Degree<BR>
    <input type="radio" name="education" value="d">Post graduate degree<BR>
    </p>

    <P>3. What is your monthly income?<BR>
    <input type="radio" name="income" value="a">Less than RM 1000<BR>
    <input type="radio" name="income" value="b">Between RM1000 to RM3000<BR>
    <input type="radio" name="income" value="c">Between RM3000 to RM5000<BR>
    <input type="radio" name="income" value="d">More than RM5000<BR>
    </p>
    
    <P>4. Your gender :<BR>
    <input type="radio" name="gender" value="a">Male<BR>
    <input type="radio" name="gender" value="b">Female<BR>
    </p>
    <div class="form-group row">
        <div class="offset-sm-3 col-sm-9">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </div>
</form>
<?php /**PATH D:\Ampps\Ampps\www\blog5.8\resources\views/survey/create.blade.php ENDPATH**/ ?>